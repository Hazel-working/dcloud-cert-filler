@echo off
chcp 65001 >nul
setlocal

set "W=%~dp0wheels"

echo ==========================================
echo  Minimal offline installer - Channel A
echo  PyYAML wheels: Python 3.9 - 3.13, 64-bit
echo  No network access required.
echo ==========================================
echo.

python -V
if errorlevel 1 (
  echo [ERROR] Python not found.
  pause
  exit /b 1
)

echo.
echo Installing PyYAML...
python -m pip install --no-index --find-links="%W%" PyYAML
if errorlevel 1 (
  echo [ERROR] Install failed.
  echo Send the output of: python -V
  pause
  exit /b 1
)

echo.
echo Done. Go to the project folder and run:
echo   python -m dcf scan
echo   python -m dcf check
echo   python -m dcf console
echo.
echo PyYAML only. Playwright / pytest are NOT included here;
echo install them later only for Channel B or unit tests.
echo.
pause
endlocal
